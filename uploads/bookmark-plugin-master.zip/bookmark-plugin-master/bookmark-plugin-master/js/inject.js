// console.log('bookmark inject.js');
myMul = (a, b) => {
  return a * b;
};
